import shutil


def locate_perl_interpreter() -> str:
    """ensures perl is installed and executable

    Returns:
        a path to the perl interpreter if found

    Raises:
        FileNotFoundError: If perl is not found
    """
    perl_intepreter_path = shutil.which("perl")
    if perl_intepreter_path == None:
        raise FileNotFoundError("Perl was not found in PATH")
    else:
        return perl_intepreter_path
