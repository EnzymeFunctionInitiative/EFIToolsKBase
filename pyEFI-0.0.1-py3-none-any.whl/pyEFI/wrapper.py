import os
import subprocess

from . import util


class EFIWrapper:
    """Creates a handle through which EFITools can be called"""

    def __init__(self, efitools_entrypoint="efi.pl", path_to_perl=""):
        """Default constructor

        Raises:
            FileNotFoundError: EFITools is not installed correctly
            PermissionError: EFITools was found but is not readable and not
                             executable
            OSError: The constructor attempts to call EFITools with no args
                     to make sure there are no execution format errors
        """
        # find perl or validate the location that the user supplied
        if path_to_perl == "":
            self.perl_interpreter_path = util.locate_perl_interpreter()
        else:
            if os.path.exists(path_to_perl):
                if os.access(path_to_perl, os.X_OK):
                    self.perl_interpreter_path = path_to_perl
                else:
                    raise PermissionError(f"Perl at '{path_to_perl}' is not executable")
            else:
                raise FileNotFoundError(f"Perl at '{path_to_perl}' does not exist")
        self.efitools_entrypoint = [self.perl_interpreter_path, efitools_entrypoint]

        # test that the EFITools script exists...
        if not os.path.exists(self.efitools_entrypoint[1]):
            raise FileNotFoundError(
                f"Could not find file '{self.efitools_entrypoint[1]}' needed to run EFITools"
            )
        # ...and is readable by us
        if not os.access(
            self.efitools_entrypoint[1],
            os.R_OK,
        ):
            raise PermissionError(f"Do not have read permissions on '{self.efitools_entrypoint[1]}'")

        # try to run EFI tools and get help text as a final check
        test_run = self._run_command(["help"])
        if test_run.returncode != 0:
            raise AssertionError(
                f"Testing command '{test_run}' failed: stdout is '{test_run.stdout}' and stderr is '{test_run.stderr}'"
            )

    def _run_command(self, cmd_args: list) -> subprocess.CompletedProcess:
        """internal function called by each of the subcommand functions

        Args:
            `cmd_args`: a list strings to be passed as args to `self.base_cmd`

        Returns:
            the CompletedProcess object from the subprocess.run call
        """
        full_cmd = self.efitools_entrypoint + cmd_args
        ran = subprocess.run(
            full_cmd,
            capture_output=True,
            text=True,
        )
        return ran

    def _est(self, args: list):
        """internal method to run `est` subcommand with args"""
        cmd_args = ["est"] + args
        return self._run_command(cmd_args)

    def est_import(self, args: list):
        """run the import subcommand under est with args"""
        cmd_args = ["import"] + args
        return self._est(cmd_args)

    def est_blast_chunk(self, args: list):
        """run the blast-chunk subcommand under est with args"""
        cmd_args = ["blast-chunk"] + args
        return self._est(cmd_args)

    def est_mux(self, path_list: list):
        """run the multiplex subcommand under est with args"""
        cmd_args = ["mux"] + path_list
        return self._est(cmd_args)

    def gnt(self, args):
        """runs `gnt` subcommand with args"""
        cmd_args = ["gnt"] + args
        return self._run_command(cmd_args)
